/* IRController */

#import <Cocoa/Cocoa.h>

#define kMaxDeviceCount 32
#define kMaxCommandCount 128

@class Command;

@interface MainController : NSObject
{
    IBOutlet NSTableView    *commandTable;
    IBOutlet NSTableView    *scriptTable;
    IBOutlet NSTextField    *lastCommandField;
    IBOutlet NSTextField    *stateField;
    IBOutlet NSWindow*      mainWindow;
    IBOutlet NSButton*      configureLastCommandButton;
    
    IBOutlet NSArrayController* scriptsController;
    IBOutlet NSArrayController* commandsController;
    
    UInt32                  lastReceivedData;               /*" last received ir data "*/
    int                     dataRepetitionCount;            /*" how often have received the same ir data in a row "*/
    NSMutableDictionary*    editedScript;               /*" name of the sript currently being edited in script panel "*/
    Command*                editedCommand;                  /*" pointer to the command currently being edited in command panel "*/
    Command*                lastReceivedCommand;            /*" the last Received command "*/
}

/*" IBActions "*/

- (IBAction) addScriptAction:(id) sender;
- (IBAction)addCommandAction:(id)sender;

- (void) udpateIOWarriorState:(BOOL) inState;
- (void) handleReceivedIRData:(char*) inData;

- (IBAction) doConfigureCommand:(id) sender;

+ (NSString*) nameForCommand:(int) inCommand;
+ (NSString*) deviceNameForAddress:(int) inCommand;

- (Command*) findCommandForDevice:(int) inDevice IRCommand:(int)inIRCommand;
- (NSMutableDictionary*) scriptWithName:(NSString*) inName;
- (NSArray*) scriptNames;
- (void) executeCommand:(Command*) inCommand repetition:(int) inRepetition;

- (void) setLastReceivedCommand:(Command*) inCommand;

@end
