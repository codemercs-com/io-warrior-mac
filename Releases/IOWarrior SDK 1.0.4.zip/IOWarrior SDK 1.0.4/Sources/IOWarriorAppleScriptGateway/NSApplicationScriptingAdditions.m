//
//  NSApplicationScriptingAdditions.m
//  IOWarriorAppleScriptGateway
//
//  Created by ilja on Fri Jan 17 2003.
//  Copyright (c) 2003 __MyCompanyName__. All rights reserved.
//

#import "NSApplicationScriptingAdditions.h"
#import "IOWarriorLib.h"
#import "IOWarriorPin.h"

// Protptypes
UInt32 swaplong (UInt32 number);
IOWarriorListNode* myDiscoverInterface0 ();
IOWarriorListNode* myDiscoverInterface1 ();
int reportSizeForInterface(IOWarriorListNode* inNode);
int MyWriteInterface1 (int reportID, void* inData);

#define kMaxPinCount 32


@implementation NSApplication (ScriptingAdditions)

NSArray*		gPins = nil;	// pins values used for communication with apple script
int				gLastReadTime = 0; // the last time interface 0 pin values have been read
int				gUserChangedPinValues = NO;
NSMutableArray* gInterface0Buffer = nil;
UInt32			gLastReadValue; // the last value read from interface0 that was different from the value read prior to it
NSTimer*		gBufferedReadTimer = nil;


-(id) handleIsIOWarriorPresentCommand:(NSScriptCommand *) command
{
    return [NSNumber numberWithInt:IOWarriorIsPresent ()];
}

-(id) handleWriteInterface0Command:(NSScriptCommand *) command
{
    int					result = 1;
	IOWarriorListNode   *theInterface;
	
	if (nil != (theInterface = myDiscoverInterface0 ()))
	{
		int				i;
		int				bufferSize;
		unsigned char 	*buffer;
		
		bufferSize = reportSizeForInterface (theInterface) ;
		buffer = malloc (bufferSize);
		for (i=0; i < bufferSize; i++)
		{
			NSNumber* tempRef;

			tempRef = [[command arguments] objectForKey:[NSString stringWithFormat:@"port%d", i]];
			if (tempRef)
				buffer[i] = [tempRef intValue];
			else
				buffer[i] = 0;
		}
		result = IOWarriorWriteToInterface (theInterface->ioWarriorHIDInterface, bufferSize, buffer);
		free (buffer);
	}
	return [NSNumber numberWithInt:result];
}

-(id) handleWriteInterface1Command:(NSScriptCommand *) command
{
    int		reportID = [[[command arguments] objectForKey:@"reportId"] intValue];
    char 	buffer[7];
    int		i;

    for (i = 0; i < 7; i++)
    {
        NSNumber* tempRef;

        tempRef = [[command arguments] objectForKey:[NSString stringWithFormat:@"byte%d", i]];
        if (tempRef)
            buffer[i] = [tempRef intValue];
        else
            buffer[i] = 0;
    }
    return [NSNumber numberWithInt:MyWriteInterface1 (reportID, buffer)];
}

-(id) handleReadInterface0Command:(NSScriptCommand *) command
{
    NSNumber			*swapBytes;
    UInt32				data = 1;
    NSMutableArray		*result = [NSMutableArray array];
    int					i;
	IOWarriorListNode*  listNode;
	int					reportSize = 0;
    
    swapBytes = [[command arguments] objectForKey:@"swap bytes"];

    if (nil != gInterface0Buffer)
    {
        // we are in buffered mode, return earliest read value, if existant
        if ([gInterface0Buffer count])
        {
            NSNumber* number = [gInterface0Buffer objectAtIndex:0];
            
            data = [number intValue];
            [gInterface0Buffer removeObjectAtIndex:0];
        }
        else
            return nil;
    }
    else
    {
		if (nil != (listNode = myDiscoverInterface0 ()))
		{
			reportSize = reportSizeForInterface(listNode);
			if (IOWarriorReadFromInterface(listNode->ioWarriorHIDInterface,0,reportSize,&data))
				return nil;
			
		}
		else
		{
			return nil;
		}
    }
    if (swapBytes != nil)
    {
        data = swaplong (data);
    }
    for (i = 0; i < reportSize; i++)
    {
        unsigned char* ptrToData = (unsigned char*) &data;

        [result addObject:[NSNumber numberWithInt:ptrToData[i]]];
    }
    return result;
}

- (id) handleReadInterface1Command:(NSScriptCommand *) command
{
    int 		reportID;
    NSNumber		*reportIDRef = [[command arguments] objectForKey:@"reportId"];
    char		buffer[7];
    NSMutableArray* 	result = [NSMutableArray array];

    if (nil != (reportIDRef =[[command arguments] objectForKey:@"reportId"]))
    {
        int i;
        
        reportID = [reportIDRef intValue];
        if (0 != IOWarriorReadInterface1 (reportID, buffer))
            return result;

        for (i = 0; i < 7; i++)
        {
            [result addObject:[NSNumber numberWithInt:buffer[i]]];
        }
    }
    return result;
}


- (NSArray*) pins
{
    //NSLog (@"pins");
    
   if (NULL == gPins)
   {
       gPins = [self buildPinArray];
       [gPins retain];
   }

   if (NO == gUserChangedPinValues)
       [self readPinArrayValues];
    
    return gPins;
}

/*" Returns an array of 32 IOWarrior pin objects. "*/
- (NSArray*) buildPinArray
{
    NSMutableArray *pins = [NSMutableArray array];
    int i;

    for (i = 0; i< kMaxPinCount; i++)
    {
        IOWarriorPin* pin = [[IOWarriorPin alloc] initWithValue:0 index:i];
        [pins addObject:pin];
		[pin release];
    }

    return [NSArray arrayWithArray:pins];
}


- (void) readPinArrayValues
/*" Updates the global pin array with values read from the IOWarrior. "*/
{
    UInt32				data = 0;
    int					i;
	IOWarriorListNode*  listNode;
	
	if (nil != (listNode = myDiscoverInterface0()))
	{
		int		reportSize ;

		reportSize = reportSizeForInterface(listNode);
		if (noErr == IOWarriorReadFromInterface (listNode->ioWarriorHIDInterface, 0, reportSize, &data))
		{
			for (i = 0; i < reportSize * 8; i++)
			{
				IOWarriorPin* pin = [gPins objectAtIndex:i];
				
				if (data & (1 << [self bitOffsetForPinIndex:i]))
					[pin setValueWithoutWriteBack:1];
				else
					[pin setValueWithoutWriteBack:0];
			}
		}
	}
}

/*" Timed selector. Scheduled when user changes a pin value. Writes current pin values back to the IOWarrior. "*/
- (void) writeBack:(NSTimer*) inTimer
{
    int		i;
    UInt32	data = 0;

    if (NULL != gPins)
    {
		IOWarriorListNode *listNode = myDiscoverInterface0();

		if (listNode)
		{
			for (i = 0; i < [gPins count]; i++)
			{
				IOWarriorPin* pin = [gPins objectAtIndex:i];
		
				if ([pin value])
				{
					data = data | (1 << [self bitOffsetForPinIndex:i]);
				}
			}
			IOWarriorWriteToInterface (listNode->ioWarriorHIDInterface, reportSizeForInterface(listNode), &data);
		}
    }
    gUserChangedPinValues = false;
}

/*" Converts a pin number to the offset of the bit representing that pin in a 32 bit value used for IOWarriorWriteInterface0. Pinindex 0 (port 0, pin 0) gets mapped to bit 24,  pinindex 7 (port 0, pin 7) get mapped to bit 31. pinindex 31 (port 3, pin 7) becomes bit 0."*/
- (int) bitOffsetForPinIndex:(int) inIndex
{
    int result = ((3 - (inIndex / 8)) * 8) + (inIndex % 8);

    //NSLog (@"mapped index %d to bit %d", inIndex, result);

    return result;
}

- (id) startBufferedReading:(NSScriptCommand *) command
{
    NSLog (@"received startBufferedReading");

    if (nil == gInterface0Buffer)
    {
        gInterface0Buffer = [[NSMutableArray alloc] init];
        gLastReadValue = 0;
        gBufferedReadTimer = [NSTimer scheduledTimerWithTimeInterval:0.1
                                         target:self
                                       selector:@selector(bufferedReadInterface0)
                                       userInfo:nil
                                        repeats:YES];
    }

    return [NSNumber numberWithInt:0];
}

- (id) stopBufferedReading:(NSScriptCommand *) command
{
    NSLog (@"received stopBufferedReading");

    [gInterface0Buffer release];
    gInterface0Buffer = nil;
    [gBufferedReadTimer invalidate];

    return [NSNumber numberWithInt:0];
}

- (id) handleReadBufferSize:(NSScriptCommand*) command
{
    int result = 0;
    
    if (gInterface0Buffer != nil)
    {
        result = [gInterface0Buffer count];
    }

    return [NSNumber numberWithInt:result];
}

- (void) bufferedReadInterface0
/*" Selector invoked by timer when buffered reading is enabled. "*/
{
    int					status;
    UInt32				data = 0;
	IOWarriorListNode   *node;
	int					reportSize;

    NSAssert (gInterface0Buffer, @"read buffer array cannot be nil here");
	if (nil == (node = myDiscoverInterface0 ()))
		return;
	
	reportSize = reportSizeForInterface (node);
    status = IOWarriorReadFromInterface (node->ioWarriorHIDInterface, 0, reportSize, &data);
    if (status)
    {
        NSLog (@"bufferedReadInterface0: reportSizeForInterface returned error");
        return;
    }

    NSLog (@"bufferedReadInterface0 read %08lx", data);

    if (data != gLastReadValue)
    {
        NSLog (@"Added %d to data buffer", data);
        [gInterface0Buffer addObject:[NSNumber numberWithInt:data]];
        gLastReadValue = data;
    }
}

- (int) reportSizeForInterfaceType:(int) inType
	/*" Returns the size of an output report written to an interface of type inType exluding size for report id. "*/
{
    int result = 0;
    
    switch (inType)
    {
        case kIOWarrior40Interface0: result = 4; break;
        case kIOWarrior40Interface1: result = 7; break;
        case kIOWarrior24Interface0: result = 2; break;
        case kIOWarrior24Interface1: result = 7; break;
    }
    return result;
}
@end

/*" Swaps the byte order of a 4 byte integer "*/
UInt32 swaplong (UInt32 number)
{
    UInt32	  	result = 0;
    char*	ptrToSrc = (char*) &number;
    char*	ptrToDest = (char*) &result;
    int		i;

    for (i= 0; i < 4; i++)
    {
        ptrToDest[i] = ptrToSrc[3 - i];
    }

    return result;
}

int MyWriteInterface1 (int inReportID, void* inData)
{
	int					result = 1;
	IOWarriorListNode   *listNode = myDiscoverInterface1 ();

	if (listNode)
	{
		char buffer[8];
        
        buffer[0] = inReportID;
        memcpy (&buffer[1], inData, 7);
		
		result = IOWarriorWriteToInterface(listNode->ioWarriorHIDInterface,8,buffer);
	}
	return result;
}
	
IOWarriorListNode* myDiscoverInterface1 ()
{
	int i;
	
	for (i = 0; i < IOWarriorCountInterfaces (); i++)
	{
		IOWarriorListNode   *listNode;
		
		listNode = IOWarriorInterfaceListNodeAtIndex (i);
		if ((listNode->interfaceType == kIOWarrior40Interface1) ||
			(listNode->interfaceType == kIOWarrior24Interface1))
		{
			return listNode;
		}
	}
	
	return NULL;
}

IOWarriorListNode* myDiscoverInterface0 ()
{
	int i;
	
	for (i = 0; i < IOWarriorCountInterfaces (); i++)
	{
		IOWarriorListNode   *listNode;
		
		listNode = IOWarriorInterfaceListNodeAtIndex (i);
		if ((listNode->interfaceType == kIOWarrior40Interface0) ||
			(listNode->interfaceType == kIOWarrior24Interface0))
		{
			return listNode;
		}
	}
	return NULL;
}

int reportSizeForInterface(IOWarriorListNode* inNode)
	/*" Returns the size of an output report written to an interface of type inType exluding size for report id. "*/
{
    int result = 0;
    
    switch (inNode->interfaceType)
    {
        case kIOWarrior40Interface0: result = 4; break;
        case kIOWarrior40Interface1: result = 7; break;
        case kIOWarrior24Interface0: result = 2; break;
        case kIOWarrior24Interface1: result = 7; break;
    }
    return result;
}