//
// Prefix header for all source files of the 'IOWarriorCocoaGUITest' target in the 'IOWarriorCocoaGUITest' project
//

#ifdef __OBJC__
    #import <Cocoa/Cocoa.h>
#endif
